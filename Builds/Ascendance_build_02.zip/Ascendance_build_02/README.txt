Ascendance Game by Joseph Grant Plaster and Philip Scott Beauchamp

To play the game, select the .html file provided in the unzipped folder and open it
with either Safari, Firefox, or Internet Explorer (Not Google Chrome).

You may need to install a plug-in to your browser. The plug-in is a trusted source;
go ahead and install it.

Once all necessary plug-ins are installed and the .html file is opened, the game is
ready to be played. Please play the game for approximately 10-15 minutes (this may require
several play throughs), while simultaneously following and filling out a survey provided at
the link below:

https://docs.google.com/forms/d/1JNv88pist7RWMJrt5tkCr5X2Tfrjqo4AF_Ww-l6Kb4Q/viewform?usp=send_form

The game's story has not been implemented. If you wish to read the brief backstory synopsis, you may
find it in the GAME_STORY.txt file, also provided in this unzipped folder. Enjoy, and thank you for your
assistance and feedback.